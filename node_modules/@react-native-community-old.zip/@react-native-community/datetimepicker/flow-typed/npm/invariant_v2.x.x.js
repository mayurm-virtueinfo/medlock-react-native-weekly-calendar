// flow-typed signature: 60de437d85342dea19dcd82c5a50f88a
// flow-typed version: da30fe6876/invariant_v2.x.x/flow_>=v0.33.x

declare module invariant {
  declare module.exports: (condition: boolean, message: string) => void;
}
