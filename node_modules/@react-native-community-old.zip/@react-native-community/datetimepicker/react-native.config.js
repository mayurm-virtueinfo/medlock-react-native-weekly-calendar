const root = process.cwd();

module.exports = {
  dependencies: {
    datetimepicker: {
      root,
    },
  },
};
