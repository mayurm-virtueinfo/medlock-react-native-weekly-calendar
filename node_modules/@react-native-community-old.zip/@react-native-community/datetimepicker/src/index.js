import RNDateTimePicker from './datetimepicker';

export default RNDateTimePicker;
